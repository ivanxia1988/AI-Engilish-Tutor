# Prompt for Codex — build teeko.app from this design kit (v0.2)

You are building **teeko.app**: a web app that teaches **spoken English to Chinese kids (about 6–12)**. Parents read the landing page (Chinese); kids use the app. Kids open a lesson from **built-in courseware**, **tap or circle** on the lesson page to hear it, and practise speaking with a **realtime voice tutor** — Teeko the sparrow, who talks with an animated beak, **hands the kid the mic** on their turn, and gives **1–3 stars**. **v1 is free**: build no pricing, plans, paywalls, editions, uploads or textbook import.

## Read in this order
1. `DESIGN.md` — the spec. It overrides everything else.
2. `mockups/*.png` — landing (desktop/mobile), lessons (desktop/mobile), study (desktop/mobile), component states.
3. `reference/*.html` + `reference/components.css` — working markup for every component and page. Port it; don't redesign it.
4. `mascot/` — all mascot SVGs, `talking-demo.html` (lip-sync reference), `teeko-mascot-sheet.png`.
5. `tokens.css` / `tokens.json` / `tailwind.preset.js` — design tokens.

## Rules
- **Tokens only.** Import `tokens.css` once; Tailwind: `presets: [require('./tailwind.preset.js')]`. No hard-coded hex/px outside tokens (exception: lesson-art colors inside lesson content). New value → edit `build_tokens.py`, run `python3 build_tokens.py`, commit outputs.
- **Fonts:** Nunito 800/900 (display, kid buttons), Inter (UI/body), Noto Sans SC (Chinese), JetBrains Mono (small labels). Self-host, `font-display: swap`.
- **Kid tap targets:** ≥56px everywhere a kid touches, 64px for primary kid actions, 96px mic. 44px only on parent/desktop controls.
- **Mascot:** a `<Mascot pose="idle|talking|handoff|thinking|celebrate" />` component that inlines the SVGs from `mascot/svg/pose-*.svg` (inline so CSS can reach `.mouth-slot`, `.eyes-*`, `.wing-*`). Talking uses `<MascotLipSync audio={...}>` built from `teeko-rig-front.svg` + the driver in DESIGN.md §6.3 (80ms RMS sampling, thresholds 0.08 / 0.32, hold ≥80ms, `oo` from phoneme hints). Without audio use `teeko-talking-loop.svg`. Never redraw or recolor the mascot.
- **Mic** is one component with `state: 'idle'|'turn'|'listening'|'processing'|'disabled'` (DESIGN.md §7.2); each state maps to a mascot pose. Handoff = 640ms spring + reduced-motion fallback.
- **Feedback = stars (1–3) + per-word `.say` + one Chinese tip.** No numeric scores, no red, never 0 stars.
- **Colors:** one orange-filled element per view; never white text on orange; mascot orange is artwork, not UI.
- **Copy:** Chinese instructions for kids (short, ≤16 characters), English for lesson content. Landing copy in Chinese for parents. Placeholder text is marked in the mockups (`.ph`) — keep it flagged until product confirms.
- **Accessibility** (DESIGN.md §9) is acceptance criteria: focus rings, aria-live state announcements, captions for everything Teeko says, `prefers-reduced-motion`, no auto mic request on load.

## Suggested build order
1. Tokens + fonts; `Logo`, `Button`, `Chip`, `Card`, `Stars`, `Say`, `SpeechBubble`, `Seg`, `MicButton`, `Mascot`, `MascotLipSync`; a `/styleguide` route matching `mockups/components-states.png`.
2. Landing `/` (§10.1), responsive.
3. Lessons `/learn` (§10.2) reading a static JSON of built-in units/lessons.
4. Study `/learn/[unit]/[lesson]` (§10.3): lesson page with 点一点/圈一圈, rail, dock, mobile sheet; wire the mic + mascot state machine to a mock voice service first, then the realtime voice API.
5. Visual QA at 1440×900 and 390×844 against `mockups/`.

## Don't
- No pricing, editions, upload/import, Chinese-for-foreigners, leaderboards, streaks, ads or external links on kid screens.
- No gradients, glass, new illustration styles or new colors.
- Don't idle-animate the mascot beyond the blink.
