# Teeko design kit v0.2 (kids 6–12 · free v1 · built-in courseware)
Start with `CODEX_PROMPT.md`, then `DESIGN.md`.
- Tokens: `python3 build_tokens.py` → tokens.css, tokens.json, tailwind.preset.js, contrast.json
- Mascot: `python3 mascot/build_mascot.py` → mascot/svg/*.svg, head icons; open `mascot/sheet.html` (turnaround, poses, visemes, loop frames) and `mascot/talking-demo.html` (lip-sync demo)
- Mockups + mascot sheet PNG: `./render.sh` (needs google-chrome, Pillow, fonts Nunito, Inter, Noto Sans CJK SC, JetBrains Mono)
- Pages: `reference/landing.html` (parents, Chinese), `reference/lessons.html`, `reference/study.html`, `reference/components.html`
