#!/usr/bin/env bash
# Render reference HTML to PNG with headless Chrome, then trim trailing empty page background.
set -e
cd "$(dirname "$0")"
shot(){ google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --virtual-time-budget=3000 --force-device-scale-factor=${4:-2} --window-size=$2,$3 --screenshot=mockups/$1.png "file://$PWD/reference/$5" >/dev/null 2>&1; }
shot landing-desktop-1440 1440 2400 2 landing.html
shot study-desktop-1440 1440 900 2 study.html
shot study-mobile-390 390 844 3 study.html
shot components-states 1440 1500 2 components.html
python3 - <<'PY'
from PIL import Image
p='mockups/landing-desktop-1440.png'; im=Image.open(p).convert('RGB'); w,h=im.size
bg=im.getpixel((5,h-5)); y=h-1
while y>0 and all(im.getpixel((x,y))==bg for x in range(0,w,7)): y-=1
im.crop((0,0,w,min(h,y+56))).save(p); print('landing',im.size,'->',y)
PY
python3 - <<'PY'
from PIL import Image
p='mockups/components-states.png'; im=Image.open(p).convert('RGB'); w,h=im.size
bg=im.getpixel((5,h-5)); y=h-1
while y>0 and all(im.getpixel((x,y))==bg for x in range(0,w,7)): y-=1
im.crop((0,0,w,y+80)).save(p)
PY
