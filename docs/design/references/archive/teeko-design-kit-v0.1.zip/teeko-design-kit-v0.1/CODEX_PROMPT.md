# Prompt for Codex — build teeko.app from this design kit

You are building **teeko.app**, a web AI speaking tutor (users open their own textbook page, circle a sentence, and practise speaking with a realtime voice tutor). This folder is the complete visual spec.

## Read in this order
1. `DESIGN.md` — the spec. It overrides everything else.
2. `mockups/*.png` — what the result must look like (landing desktop, study desktop, study mobile, component states).
3. `reference/*.html` + `reference/components.css` — working reference markup for every component and both pages. Port it; don't redesign it.
4. `tokens.css` / `tokens.json` / `tailwind.preset.js` — design tokens.

## Rules
- **Use tokens only.** Import `tokens.css` once globally. If using Tailwind, add `presets: [require('./tailwind.preset.js')]` and use the token classes (`bg-cream-50`, `text-navy-900`, `text-h2`, `font-display`, `rounded-lg`, `shadow-turn`, `animate-handoff`…). No hard-coded hex, px font sizes, radii or shadows outside tokens. Need a new value? Add it to `build_tokens.py`, run `python3 build_tokens.py`, and commit the regenerated files.
- **Fonts:** Nunito 800/900 (display/headings), Inter 400–700 (UI/body), Noto Sans SC subset (Chinese), Literata only for the textbook placeholder, JetBrains Mono for phonetic chips. Self-host via `@fontsource/*` or `next/font`; `font-display: swap`.
- **Icons:** `lucide-react`, `strokeWidth={1.75}`, sizes 16/20/24/30.
- **Logo:** in the UI use the HTML lockup (`.logo` in components.css: "Tee" navy + "ko" orange-500 in Nunito 900 + `assets/teeko-icon-180.png`). Use `assets/teeko-logo.svg` / `teeko-logo-dark.svg` for OG images/docs; favicon = `teeko-icon-32.png`, apple-touch = `teeko-icon-180.png`.
- **Mic button** is a single component with `state: 'idle' | 'turn' | 'listening' | 'processing' | 'disabled'` exactly as in DESIGN.md §6.5, plus the turn-cue handoff animation in §6.6 (640ms spring) and its reduced-motion fallback.
- **Colors:** never white text on orange, never small orange-500 text on light backgrounds (see §2.4). Exactly one orange-filled element per view.
- **Accessibility** (§8) is acceptance criteria, not polish: focus rings, aria-live state announcements, keyboard flow (Space hold-to-talk, Esc skip), 44px targets, `prefers-reduced-motion`.
- Copy in the mockups is placeholder; keep the voice (short, calm, English + one short Chinese line).

## Suggested build order
1. Global styles + tokens + fonts; `Logo`, `Button`, `Input/Field`, `Card`, `Chip`, `MicButton`, `TurnCue`; a `/styleguide` route that reproduces `mockups/components-states.png`.
2. Landing page `/` (DESIGN.md §9.1) — responsive; compare against `landing-desktop-1440.png` at 1440 wide.
3. Study screen `/study/[bookId]/[page]` (§9.2) — layout, page canvas with Move/Tap/Circle tools, selection toolbar, rail feed, dock; mobile bottom sheet. Wire the mic state machine to a mock voice service first.
4. Visual QA: screenshot at 1440×900 and 390×844 and diff against `mockups/`.

## Don't
- Don't add gradients, glass, extra illustration, gamification, or new colors.
- Don't use the sparrow as decoration or animate it idly.
- Don't change component dimensions in DESIGN.md without updating the doc.
