# Teeko design kit v0.1
Start with `CODEX_PROMPT.md`, then `DESIGN.md`.
- Regenerate tokens: `python3 build_tokens.py` → tokens.css, tokens.json, tailwind.preset.js, contrast.json
- Re-render mockups: `./render.sh` (needs google-chrome and Pillow; fonts Nunito, Inter, Noto Sans SC, Literata, JetBrains Mono installed locally)
- Open `reference/*.html` directly in a browser to inspect.
